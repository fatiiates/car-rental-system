-- phpMyAdmin SQL Dump
-- version 4.9.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: May 25, 2020 at 05:18 PM
-- Server version: 8.0.17
-- PHP Version: 7.3.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `oto_kiralama`
--

-- --------------------------------------------------------

--
-- Table structure for table `arac`
--

CREATE TABLE `arac` (
  `arac_id` int(11) NOT NULL,
  `arac_plaka` varchar(20) COLLATE utf8mb4_turkish_ci NOT NULL,
  `arac_bilgi_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_turkish_ci;

--
-- Dumping data for table `arac`
--

INSERT INTO `arac` (`arac_id`, `arac_plaka`, `arac_bilgi_id`) VALUES
(1, '15lna76123', 1),
(4, '34CPY56', 3),
(6, '16BRS1963', 1);

-- --------------------------------------------------------

--
-- Table structure for table `arac_kiralama`
--

CREATE TABLE `arac_kiralama` (
  `kira_id` int(11) NOT NULL,
  `arac_id` int(11) NOT NULL,
  `musteri_id` int(11) NOT NULL,
  `kira_tarih` datetime NOT NULL,
  `kira_bitis` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_turkish_ci;

--
-- Dumping data for table `arac_kiralama`
--

INSERT INTO `arac_kiralama` (`kira_id`, `arac_id`, `musteri_id`, `kira_tarih`, `kira_bitis`) VALUES
(1, 6, 2, '2020-06-01 00:00:00', '2020-06-02 00:00:00'),
(7, 4, 5, '2020-05-16 02:02:00', '2020-05-18 02:02:00');

-- --------------------------------------------------------

--
-- Table structure for table `kullanici`
--

CREATE TABLE `kullanici` (
  `kullanici_id` int(11) NOT NULL,
  `kullanici_ad` varchar(50) COLLATE utf8mb4_turkish_ci NOT NULL,
  `kullanici_soyad` varchar(50) COLLATE utf8mb4_turkish_ci NOT NULL,
  `kullanici_user_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_turkish_ci NOT NULL,
  `kullanici_mail` varchar(100) COLLATE utf8mb4_turkish_ci NOT NULL,
  `kullanici_sifre` varchar(50) COLLATE utf8mb4_turkish_ci NOT NULL,
  `kullanici_telefon` varchar(10) COLLATE utf8mb4_turkish_ci NOT NULL,
  `kullanici_adres` varchar(1000) CHARACTER SET utf8mb4 COLLATE utf8mb4_turkish_ci NOT NULL,
  `kullanici_rol` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_turkish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_turkish_ci;

--
-- Dumping data for table `kullanici`
--

INSERT INTO `kullanici` (`kullanici_id`, `kullanici_ad`, `kullanici_soyad`, `kullanici_user_id`, `kullanici_mail`, `kullanici_sifre`, `kullanici_telefon`, `kullanici_adres`, `kullanici_rol`) VALUES
(1, 'Fatih', 'ATEŞ', 'fatiiates', 'fatiiates@gmail.com4', '202cb962ac59075b964b07152d234b70', '5444735349', 'Vatan mahallesi 3. sevenler sokak', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `mesaj`
--

CREATE TABLE `mesaj` (
  `mesaj_id` int(11) NOT NULL,
  `mesaj_icerik` varchar(500) COLLATE utf8mb4_turkish_ci NOT NULL,
  `mesaj_tarih` datetime NOT NULL,
  `mesaj_gonderen` varchar(50) COLLATE utf8mb4_turkish_ci NOT NULL,
  `mesaj_mail` varchar(100) COLLATE utf8mb4_turkish_ci NOT NULL,
  `mesaj_tel` varchar(10) COLLATE utf8mb4_turkish_ci NOT NULL,
  `mesaj_durum` bit(1) NOT NULL DEFAULT b'0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_turkish_ci;

--
-- Dumping data for table `mesaj`
--

INSERT INTO `mesaj` (`mesaj_id`, `mesaj_icerik`, `mesaj_tarih`, `mesaj_gonderen`, `mesaj_mail`, `mesaj_tel`, `mesaj_durum`) VALUES
(3, 'sdagasgdsagdsagdsa', '0000-00-00 00:00:00', 'fatih', 'fatiiates@mail.com', '5444735349', b'1'),
(4, 'sdhsdfhfsdhfsdh', '2020-05-22 21:40:28', 'fatih', 'fatiiates@mail.com', '5444735349', b'0');

-- --------------------------------------------------------

--
-- Table structure for table `mevcut_arac_bilgi`
--

CREATE TABLE `mevcut_arac_bilgi` (
  `arac_bilgi_id` int(11) NOT NULL,
  `arac_marka` varchar(50) COLLATE utf8mb4_turkish_ci NOT NULL,
  `arac_model` varchar(50) COLLATE utf8mb4_turkish_ci NOT NULL,
  `arac_yil` smallint(4) NOT NULL,
  `arac_kira_ucret` decimal(6,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_turkish_ci;

--
-- Dumping data for table `mevcut_arac_bilgi`
--

INSERT INTO `mevcut_arac_bilgi` (`arac_bilgi_id`, `arac_marka`, `arac_model`, `arac_yil`, `arac_kira_ucret`) VALUES
(1, 'Renault', 'Megane', 2000, '555.33'),
(3, 'AUDİ', 'Q9', 2020, '999.99');

-- --------------------------------------------------------

--
-- Table structure for table `musteri`
--

CREATE TABLE `musteri` (
  `musteri_id` int(11) NOT NULL,
  `musteri_ad` varchar(50) COLLATE utf8mb4_turkish_ci NOT NULL,
  `musteri_soyad` varchar(50) COLLATE utf8mb4_turkish_ci NOT NULL,
  `musteri_TC` varchar(11) COLLATE utf8mb4_turkish_ci NOT NULL,
  `musteri_mail` varchar(100) COLLATE utf8mb4_turkish_ci NOT NULL,
  `musteri_adres` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_turkish_ci NOT NULL,
  `musteri_telefon` varchar(10) COLLATE utf8mb4_turkish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_turkish_ci;

--
-- Dumping data for table `musteri`
--

INSERT INTO `musteri` (`musteri_id`, `musteri_ad`, `musteri_soyad`, `musteri_TC`, `musteri_mail`, `musteri_adres`, `musteri_telefon`) VALUES
(2, 'Fatih1', 'ateş', '11122233342', 'fatiiates@gmail.com', 'asdsadasdsa', '5554443322'),
(5, 'Osman ', 'Yılmaz ', '11122233344', 'osmyl@osmyl.com', 'sdgasgsagasdgasd', '4333543454');

-- --------------------------------------------------------

--
-- Table structure for table `site_ayar`
--

CREATE TABLE `site_ayar` (
  `ayar_id` int(11) NOT NULL,
  `ayar_tip` varchar(50) COLLATE utf8mb4_turkish_ci NOT NULL,
  `ayar_deger` varchar(2500) COLLATE utf8mb4_turkish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_turkish_ci;

--
-- Dumping data for table `site_ayar`
--

INSERT INTO `site_ayar` (`ayar_id`, `ayar_tip`, `ayar_deger`) VALUES
(18, 'ISLETME_AD', 'Prusa Oto'),
(19, 'HAKKIMIZDA', 'HAKKIMIZDALorem Ipsum, dizgi ve baskı endüstrisinde kullanılan mıgır metinlerdir. Lorem Ipsum, adı bilinmeyen bir matbaacının bir hurufat numune kitabı oluşturmak üzere bir yazı galerisini alarak karıştırdığı 1500\'lerden beri endüstri standardı sahte metinler olarak kullanılmıştır. Beşyüz yıl boyunca varlığını sürdürmekle kalmamış, aynı zamanda pek değişmeden elektronik dizgiye de sıçramıştır. 1960\'larda Lorem Ipsum pasajları da içeren Letraset yapraklarının yayınlanması ile ve yakın zamanda Aldus PageMaker gibi Lorem Ipsum sürümleri içeren masaüstü yayıncılık yazılımları ile popüler olmuştur.'),
(20, 'VIZYON', 'VIZYONLorem Ipsum, dizgi ve baskı endüstrisinde kullanılan mıgır metinlerdir. Lorem Ipsum, adı bilinmeyen bir matbaacının bir hurufat numune kitabı oluşturmak üzere bir yazı galerisini alarak karıştırdığı 1500\'lerden beri endüstri standardı sahte metinler olarak kullanılmıştır. Beşyüz yıl boyunca varlığını sürdürmekle kalmamış, aynı zamanda pek değişmeden elektronik dizgiye de sıçramıştır. 1960\'larda Lorem Ipsum pasajları da içeren Letraset yapraklarının yayınlanması ile ve yakın zamanda Aldus PageMaker gibi Lorem Ipsum sürümleri içeren masaüstü yayıncılık yazılımları ile popüler olmuştur.'),
(21, 'MISYON', 'MISYONLorem Ipsum, dizgi ve baskı endüstrisinde kullanılan mıgır metinlerdir. Lorem Ipsum, adı bilinmeyen bir matbaacının bir hurufat numune kitabı oluşturmak üzere bir yazı galerisini alarak karıştırdığı 1500\'lerden beri endüstri standardı sahte metinler olarak kullanılmıştır. Beşyüz yıl boyunca varlığını sürdürmekle kalmamış, aynı zamanda pek değişmeden elektronik dizgiye de sıçramıştır. 1960\'larda Lorem Ipsum pasajları da içeren Letraset yapraklarının yayınlanması ile ve yakın zamanda Aldus PageMaker gibi Lorem Ipsum sürümleri içeren masaüstü yayıncılık yazılımları ile popüler olmuştur.'),
(22, 'ADRES', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. also the leap into electronic typesetting, remaining essentially desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.'),
(23, 'TELEFON', '5444735349'),
(24, 'MAIL', 'noreply@oto.com'),
(25, 'GOOGLE_URL', 'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3047.982137005641!2d29.053173815388927!3d40.18721097939249!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x14ca3dfd02579919%3A0xb252d61ec2e9d354!2sTophane%20Mesleki%20Ve%20Teknik%20Anadolu%20Lisesi!5e0!3m2!1str!2str!4v1590189993755!5m2!1str!2str'),
(26, 'KEYWORDS', 'Araç, kiralama, günlük, yıllık'),
(27, 'DESCRIPTION', 'Açıklama'),
(29, 'AUTHOR', 'Fatih ATES');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `arac`
--
ALTER TABLE `arac`
  ADD PRIMARY KEY (`arac_id`),
  ADD KEY `arac_bilgi_id` (`arac_bilgi_id`);

--
-- Indexes for table `arac_kiralama`
--
ALTER TABLE `arac_kiralama`
  ADD PRIMARY KEY (`kira_id`),
  ADD KEY `arac_id` (`arac_id`),
  ADD KEY `musteri_id` (`musteri_id`);

--
-- Indexes for table `kullanici`
--
ALTER TABLE `kullanici`
  ADD PRIMARY KEY (`kullanici_id`);

--
-- Indexes for table `mesaj`
--
ALTER TABLE `mesaj`
  ADD PRIMARY KEY (`mesaj_id`);

--
-- Indexes for table `mevcut_arac_bilgi`
--
ALTER TABLE `mevcut_arac_bilgi`
  ADD PRIMARY KEY (`arac_bilgi_id`);

--
-- Indexes for table `musteri`
--
ALTER TABLE `musteri`
  ADD PRIMARY KEY (`musteri_id`);

--
-- Indexes for table `site_ayar`
--
ALTER TABLE `site_ayar`
  ADD PRIMARY KEY (`ayar_id`),
  ADD UNIQUE KEY `ayar_tip` (`ayar_tip`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `arac`
--
ALTER TABLE `arac`
  MODIFY `arac_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `arac_kiralama`
--
ALTER TABLE `arac_kiralama`
  MODIFY `kira_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `kullanici`
--
ALTER TABLE `kullanici`
  MODIFY `kullanici_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `mesaj`
--
ALTER TABLE `mesaj`
  MODIFY `mesaj_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `mevcut_arac_bilgi`
--
ALTER TABLE `mevcut_arac_bilgi`
  MODIFY `arac_bilgi_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `musteri`
--
ALTER TABLE `musteri`
  MODIFY `musteri_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `site_ayar`
--
ALTER TABLE `site_ayar`
  MODIFY `ayar_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `arac`
--
ALTER TABLE `arac`
  ADD CONSTRAINT `arac_ibfk_1` FOREIGN KEY (`arac_bilgi_id`) REFERENCES `mevcut_arac_bilgi` (`arac_bilgi_id`);

--
-- Constraints for table `arac_kiralama`
--
ALTER TABLE `arac_kiralama`
  ADD CONSTRAINT `arac_kiralama_ibfk_1` FOREIGN KEY (`musteri_id`) REFERENCES `musteri` (`musteri_id`),
  ADD CONSTRAINT `arac_kiralama_ibfk_2` FOREIGN KEY (`arac_id`) REFERENCES `arac` (`arac_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
