    <footer id="footer" class="animated fadeIn shadow-lg text-center custom-purple p-5 d-flex float-left col-md-12 align-items-center ">
      <div class="container align-items-center d-flex">
        <div class="col-md-12 text-light mb-0">
          <span class="footer-info" >© Copyright 2020 </span>
          <span class="footer-divider" >-</span>
          <span class="footer-info" >Tüm hakları saklıdır.</span>
        </div>
      </div>
      <a href="/contact" class="h5 btn btn-outline-light p-2 pl-4 pr-4 mb-0">İletişim</a>
    </footer>
    <?php
    require_once(ROOT_DIR.'/layout/foot.php');
     ?>
  </body>
</html>
