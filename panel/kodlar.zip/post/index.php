<?php

header("Location:../");
exit;

 ?>
