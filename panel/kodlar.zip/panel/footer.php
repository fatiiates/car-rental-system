    <footer id="footer" class="animated fadeIn shadow-lg text-center custom-purple p-5 d-flex float-left col-md-12">
      <div class="container align-items-center d-flex">
        <div class="col-md-12 text-light mb-0">
          <span class="footer-info" >© Copyright 2020 </span>
          <span class="footer-divider" >-</span>
          <span class="footer-info" >Tüm hakları saklıdır.</span>
        </div>
      </div>
    </footer>
    <?php
    require_once(ROOT_DIR.'/layout/foot.php');
     ?>
  </body>
</html>
